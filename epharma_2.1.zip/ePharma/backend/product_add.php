<?php
if (isset($_POST['add_drug']))
{
	// echo "Nepal";exit();
	$name = $_POST['name'];
	$category = $_POST['category'];
	$price = $_POST['price'];
	$brand = $_POST['brand'];
	$stock = $_POST['stock'];
	$seller = $_POST['pharmacy'];
	$sql = "INSERT INTO `product` (`name`,`category`,`price`,`brand`,`stock`,`pharmacy`) VALUES ('$name','$category','$price','$brand','$stock','$seller')";
	require_once("DBConnect.php");
	if (mysqli_query($conn, $sql))
	{
	    // echo "New record created successfully.";
	    header('Location: product_list.php');
	} 
	else
	{
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
	mysqli_close($conn);
}
?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php include 'include/navigation.php';?>
	<div class="container">
		<h1>Add Product</h1>
		<form action="" method="POST" name="drug">
			<table class="table-sm mb-2">
				<tr>
					<td>Product Name : </td>
					<td><input type="text" name="name" class="form-control form-control-sm" required></td>
				</tr>
				<tr>
					<td>Category : </td>
					<td>
						<select name="category" class="custom-select mb-3" required>
							<option disabled selected>--Category--</option>
							<option>A</option>
							<option>B</option>
							<option>C</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>Price / piece : </td>
					<td><input type="number" name="price" class="form-control form-control-sm" min="5" required></td>
				</tr>
				<tr>
					<td>Brand : </td>
					<td><input type="text" name="brand" class="form-control form-control-sm" required></td>
				</tr>
				<tr>
					<td>Stock : </td>
					<td><input type="number" name="stock" class="form-control form-control-sm" required min="1" placeholder="min. 1"></td>
				</tr>
				<tr>
					<td>Seller : </td>
					<td>
						<?php 	
							$a = $_SESSION['username'];             
							$b = "SELECT * FROM `user` WHERE `username`='$a'";
							$c = mysqli_query($conn,$b);
							$d = mysqli_fetch_assoc($c);
							$admin_id = $d['admin_id'];
							$usertype =  $d['usertype'];
	                        $b2 = "SELECT * FROM `pharmacy` WHERE `id`='$admin_id'";
	                        $c2 = mysqli_query($conn,$b2);
	                        $d2 = mysqli_fetch_assoc($c2);
						?>
						<input type="text" name="pharmacy" class="form-control form-control-sm mb-2" required <?php if($usertype=='Admin'){?>value="<?php echo $d2['name'];?>" disabled <?php } ?>>
						<?php ?>
					</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td class="text-center"><button type="submit" name="add_drug" class="btn btn-success btn-block">Add</button></td>
				</tr>
			</table>
		</form>
		<?php include 'include/footer.php';?>
	</div>
</body>
</html>