<?php 
if(empty($_SESSION))
  {   
    session_start();
    if(isset($_COOKIE["member_login"]))
    { 
      $_SESSION['username'] = $_COOKIE["member_login"];
      echo "<script>window.location='Cart.php';</script>";
      exit;
    }
  }
if(!isset($_SESSION['username'])) { 
  echo "<script>window.location='../login.php';</script>";
  exit;
}
?>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="../css/argon.css?v=1.2.0">
<style type="text/css">
  .nav-item
  { margin-bottom: 5px; }
  .container{margin-left: 15%;}

        th,td
        { padding-top: 2px;
            padding-bottom: 2px;
        }
        li a {
          display: block;
          color: #000;
          padding: 8px 16px;
          text-decoration: none;
        }

        li a.active {
          background-color: #4CAF50;
          color: white;
        }

        li a:hover:not(.active) {
          background-color: #39b97e;
          border-radius: 25px;
          color: white;
        }
</style>
<nav class="sidenav navbar navbar-vertical bg-gradient-gray-dark navbar-expand-sm navbar-light bg-white" id="sidenav-main" style="color: white;">
        <p class="text-center mt-2">Accessing as : <?php echo ucwords($_SESSION['username']."<br>"); 
          require_once("DBConnect.php");
          $a = $_SESSION['username'];
          $b = "SELECT * FROM `user` WHERE `username`='$a'";
          $c = mysqli_query($conn,$b);
          $d = mysqli_fetch_assoc($c);
          echo "<font class='text-light'>UserType : ".$d['usertype']."</font>";
          ?>
        </p>
    <div class="navbar-inner mt--4">
            <div class="collapse navbar-collapse" id="sidenav-collapse-main">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" href="dashboard.php">
              <i class="ni ni-tv-2 text-primary"></i>
              <span class="nav-link-text">Dashboard</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">
              <i class="ni ni-bullet-list-67 text-default"></i>
              <span class="nav-link-text">Tables</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="#">
              <i class="ni ni-send text-dark"></i>
              <span class="nav-link-text">Send Email</span>
            </a>
          </li>
        </ul>
          <hr class="my-3">
            <a class="nav-link" href="logout.php">
              <i class="ni ni-key-25 text-info ml--2"></i>
              <span class="nav-link-text text-muted ml-5">Log Out</span>
            </a>
      </div>
    </div>
</nav>

<ul style="list-style-type: none;margin-top: .5%;padding: 0;width: 15%;background-color:rgb(255, 255, 255);position: fixed;min-height:200px;overflow: auto;margin-left: 83%;" class="rounded bg-gradient-green">
          <li><a class="active" href="index.php">Widget</a></li>
          <?php if($d['usertype']=="SuperAdmin"){ ?>
            <li><a href="user_list.php">List User</a></li>
            <li><a href="user_add.php">Add User</a></li>
            <li><a href="pharmacy_list.php">List Pharmacy</a></li>
            <li><a href="pharmacy_add.php">Add Pharmacy</a></li>
          <?php } ?>
          <li><a href="product_list.php">List Product</a></li>
          <li><a href="product_add.php">Add Product</a></li>
          <li><a href="category_list.php">List Category</a></li>
          <li><a href="category_add.php">Add Category</a></li>
          <li><a href="brand_list.php">List Brands</a></li>
          <li><a href="brand_add.php">Add Brands</a></li>
          <li><a href="sales_list.php">View Sales</a></li>
          <li><a href="transaction_list.php">View Transactions</a></li>
</ul>