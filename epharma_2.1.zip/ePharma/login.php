<?php include 'include/navbar.php' ?>

<?php
if(isset($_COOKIE["member_login"]))
{	
	$_SESSION['username'] = $_COOKIE["member_login"];
	echo "<script>window.location='Cart.php';</script>";
	exit;
}
if(isset($_SESSION['username']))
{
	echo "<script>window.location='Cart.php';</script>"; 
	exit;
}

if(isset($_POST['login']))
{
	$u = $_POST['username'];
	$p = $_POST['password'];

	$sql = "SELECT * FROM `user` WHERE `username`='$u' AND `password`='$p';";
//echo $sql;
	require_once('backend/DBConnect.php');
	$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result) > 0) 
	{

$_SESSION['username'] = $u;
$row = mysqli_fetch_assoc($result);
//echo "<pre>"; print_r($row);exit;
$_SESSION['u_id'] = $row['id'];
if(!empty($_POST["remember_me"])) {
	setcookie ("member_login",$_POST["username"],time()+(60 * 60)); /* expire in 1 hour */
} else {
	if(isset($_COOKIE["member_login"])) {
		setcookie ("member_login","");
	}
}
require_once("DBConnect.php");
$a = $_SESSION['username'];
$b = "SELECT * FROM `user` WHERE `username`='$a'";
$c = mysqli_query($conn,$b);
$d = mysqli_fetch_assoc($c);
if ($d['usertype']=="SuperAdmin" || $d['usertype']=="Admin")
{ echo "<script>window.location='backend/dashboard.php';</script>"; }
else
{ echo "<script>window.location='Cart.php';</script>"; }
		
exit; 
}else{
	echo "<script>alert('Username or Password Incorrect!');</script>";
	echo "<script>window.location='login.php';</script>";
	exit;
}
}
?>
 


<!DOCTYPE html>
<html>
	<head>
		<title>Log In</title>
	</head>
	<body>
		<div class="container" style="width: 60%;padding-left: 2rem;padding-right:2rem;">
			<form method="POST" class="jumbotron mt-5">
				<h4 align="left">Log In</h4><br>
				<div class="form-group">
					<label for="username">Your Username :</label>
					<input type="text" class="form-control" name="username" required>
				</div>
				<div class="form-group">
					<label for="password">Your Password:</label>
					<input type="password" class="form-control" name="password" required>
				</div><br>
				<input type="submit" class="btn btn-outline-secondary" value="Log In" name="login" style="float:right;width: 25%;">
				<p>Forgot Password ? Reset your password <a href="email_verification.php" style="text-decoration: underline;">here</a>..</p>
			</form>
			<p>Not registered yet ? <a href="register.php">Register with us</a> .</p>
		</div>
		<?php include 'include/footer.php' ?>
	</body>
</html>