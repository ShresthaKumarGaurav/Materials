<?php include 'include/navbar.php' ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php 
	 $query = "SELECT * FROM shopping ORDER BY id ASC ";
	 mysqli_connect($conn,$query); ?>
	<div class="container">
		<div class="jumbotron"> 
				<table class="text-justify text-center mt-5" width=100%>
					<tr>
						<td style="width: 300px;"><img src="images/1.jpg" style="height: 300px;"></td>
						<td>kslfngkldfngkdfnfkldsngkldf</td>
					</tr>
					<tr>
						<td>Drug</td>
					</tr>
					<tr>
						<td>Price : Free Ho Hai Gaich :D</td>
					</tr>
					<tr>
						<td> &nbsp;</td>
					</tr>
					<tr>
						<td class="btn btn-info btn-block rounded">Add to Cart</td>
					</tr>
				</table>
		</div>
	</div>


</body>
</html>