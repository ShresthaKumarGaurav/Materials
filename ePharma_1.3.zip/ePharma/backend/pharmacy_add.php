<?php
if (isset($_POST['add'])) {
	// echo "Nepal";exit();
	$name = $_POST['name'];
	$reg = $_POST['reg'];
	$address = $_POST['address'];
	$contact = $_POST['contact'];
	$owner = $_POST['owner'];
			$sql = "INSERT INTO `pharmacy` (`name`,`registration_number`,`address`,`contact`,`owner`) VALUES ('$name','$reg','$address','$contact','$owner')";
		require_once("DBConnect.php");
		if (mysqli_query($conn, $sql)) {
		    // echo "New record created successfully.";
		    header('Location: pharmacy_list.php');
		} else {
		    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
		}
?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php include 'include/navigation.php';?>
	<div class="container">
		<h1>Add Pharmacy</h1>
		<form action="" method="POST" name="drug">
			<table class="table-sm mb-2">
				<tr>
					<td>Pharmacy Name : </td>
					<td><input type="text" name="name" class="form-control form-control-sm mb-2" required></td>
				</tr>
				</tr>
				<tr>
					<td>Registration Number : </td>
					<td><input type="number" name="reg" class="form-control form-control-sm mb-2" required></td>
				</tr>
				<tr>
					<td>Address : </td>
					<td><input type="text" name="address" class="form-control form-control-sm mb-2" required></td>
				</tr>
				<tr>
					<td>Contact : </td>
					<td><input type="tel" name="contact" class="form-control form-control-sm mb-2" required pattern="[6-9]{2}[0-9]{8}"></td>
					<td>Format : 9812345678</td>
				</tr>
				<tr>
					<td>Proprietor : </td>
					<td><input type="text" name="owner" class="form-control form-control-sm mb-2" required></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td class="text-center"><button type="submit" name="add" class="btn btn-success btn-block">Add</button></td>
				</tr>
			</table>
		</form>
		<?php include 'include/footer.php';?>
	</div>
</body>
</html>