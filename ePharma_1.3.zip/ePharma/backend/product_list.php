<?php
require_once("DBConnect.php");
$sql = "SELECT *,P.id AS pid,P.name AS pname FROM product P LEFT JOIN category C ON P.category=C.name";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<?php include 'include/navigation.php';?>
<div class="container">
    <h1>Product List</h1>
    <a href="product_add.php"><img src="images/bootstrap.jpg" height="30px">+</a>
    <table class="text-center table-bordered table-primary table-hover table-sm mb-2 ">
        <tr>
            <th>S.N.</th>
            <th>Product Code</th>
            <th>Product Name</th>
            <th>Category</th>
            <th>Description</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Seller</th>
            <th>Action</th>
        </tr>
        <?php
        if (mysqli_num_rows($result) > 0) {
            $i=0;
            while($row = mysqli_fetch_assoc($result)) {
        ?>
                <tr>
                    <td><?= ++$i;?></td>
                    <td>EP<?= $row["pid"];?></td>
                    <td><?= $row["pname"];?></td>
                    <td><?= $row["category"];?></td>
                    <td><?= $row["description"]; ?></td>
                    <td><?= $row["price"]; ?></td>
                    <td><?= $row["stock"];?></td>
                    <td><?= $row["pharmacy"];?></td>
                    <td><a href="product_update.php?id=<?= $row['pid'];?>">Edit</a>&nbsp; | <a onclick="return confirm('Are you sure you want to delete this entry?')" href="product_delete.php?id=<?= $row['pid'];?>">Delete</a></td>
                </tr>
                <?php
            }   
        } else {
            ?>
            <tr>
                <td colspan="6">No Record(s) found.</td>
            </tr>
            <?php
        }
        ?>
        <?php 
        mysqli_close($conn);
        ?>
    </table>
    <?php include 'include/footer.php';?>
</div>
</body>
</html>