<?php
require_once("DBConnect.php");
$sql = "SELECT * FROM transaction";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<?php include 'include/navigation.php';?>
<div class="container">
    <h1>View Transactions</h1>
    <img src="images/bootstrap.jpg" height="30px">
    <table class="text-center table-bordered table-primary table-hover table-sm mb-2 ">
        <tr>
            <th>S.N.</th>
            <th>Order ID</th>
            <th>Order By</th>
            <th>Sold By</th>
            <th>Total Amount</th>
            <th>Transaction Type</th>
            <th>Remarks</th>
        </tr>
        <?php
        if (mysqli_num_rows($result) > 0) {
            $i=0;
            while($row = mysqli_fetch_assoc($result)) {
        ?>
                <tr>
                    <td><?= ++$i;?></td>
                    <td><?= $row["order_id"];?></td>
                    <td><?= $row["user_id"];?></td>
                    <td><?= $row["username"];?></td>
                    <td><?= $row["pharmacy_id"];?></td>
                    <td><?= $row["total_amount"];?></td>
                    <td><?= $row["remarks"];?></td>
                    <td><a onclick="return confirm('Are you sure you want to delete this entry?')" href="transaction_delete.php?id=<?= $row['id'];?>">Delete</a></td>
                </tr>
                <?php
            }   
        } else {
            ?>
            <tr>
                <td colspan="7">No Record(s) found.</td>
            </tr>
            <?php
        }
        ?>
        <?php 
        mysqli_close($conn);
        ?>
    </table>
    <?php include 'include/footer.php';?>
</div>
</body>
</html>