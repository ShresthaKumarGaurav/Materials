<?php include 'include/navbar.php' ?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <font class="font-weight-bolder d-flex justify-content-center text-center mt-3" style="font-size: 120%"> Order placed successfully !!<br> <br> Your Order Details : <br></font>
    <table class="table table-round table-primary table-hover mb-5" align="center" style="width: auto;">
        <tr>
            <td style="font-size: 100%;text-align: right;">Order Number : </td>
            <td style="font-size: 100%;text-align: left;">00000000000000000000</th>
        </tr>
        <tr>
            <td style="font-size: 100%;text-align: right;">Transaction Code : </td>
            <td style="font-size: 100%;text-align: left;">00000</td>
        </tr>
        <tr>
            <td style="font-size: 100%;text-align: right;">Ordered By : </td>
            <td style="font-size: 100%;text-align: left;">00000000</td>
        </tr>
        <tr>
            <td style="font-size: 100%;text-align: right;">Shipped By : </td>
            <td style="font-size: 100%;text-align: left;">000000</td>
        </tr>
    </table>
   <a href="health_tips.php" class="btn btn-lg btn-block btn-primary" style="width: 40%;margin-left: 30%">Explore the site..</a>
</body>
</html>