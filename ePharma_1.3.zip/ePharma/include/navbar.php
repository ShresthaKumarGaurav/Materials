<?php session_start(); ?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/argon.css">
<div class="navbar">
	<a href="index.php" class="logo" style="text-decoration: none;">ePharma
		<?php
			if (isset($_SESSION['username'])) 
			{
				echo "welcomes you, "."<span class='text-dark font-weight-bold'>".$_SESSION['username']."</span>";
			}
		?>
	</a>
	<ul class="nav">
		<li><a href="index.php" style="text-decoration: none;">Home</a></li> 
		<li><a href="about.php" style="text-decoration: none;">About Us</a></li>
		<li><a href="cart.php" style="text-decoration: none;">Products</a></li>
		<li><a href="#" style="text-decoration: none;">Health Tips</a></li>
		<li><a href="#" style="text-decoration: none;">Contact Us</a></li>
		<li><a href="checkout.php" style="text-decoration: none;">My Cart</a></li>
	</ul>
	<?php 
	    include "backend/DBConnect.php";
	    if(isset($_SESSION['username']))
	    {
	        $sql = "SELECT firstname FROM user WHERE id=1";
	        $query = mysqli_query($conn,$sql);
	        echo  "<a href='backend/logout.php'>Logout</a>";
	    }
	    else  
	    { echo "<a href='login.php'>Login</a>"; } 
	?>        
</div>