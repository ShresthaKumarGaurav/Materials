<?php include 'include/navbar.php' ?>
<?php
    if (isset($_POST["update"]))
    {
            $item_array = array(
                    'id' => $_POST["hidden_id"],
                    'name' => $_POST["hidden_name"],
                    'price' => $_POST["hidden_price"],
                    'quantity' => $_POST["quantity"],
                );
            $index = array_search($_POST['hidden_id'],array_column($_SESSION["cart"],"id"));
            $_SESSION["cart"][$index] = $item_array;
    }
    if (isset($_POST["add"]))
    {
        if (isset($_SESSION["cart"]))
        {
            $item_array_id = array_column($_SESSION["cart"],"id");
            $item_array = array(
                    'id' => $_POST["hidden_id"],
                    'name' => $_POST["hidden_name"],
                    'price' => $_POST["hidden_price"],
                    'quantity' => $_POST["quantity"],
                );
            if (!in_array($_POST["hidden_id"],$item_array_id))
            { 
                $count = count($_SESSION["cart"]);
                for ($i=0; $i <=$count ; $i++)
                { 
                    if (!isset($_SESSION['cart'][$i]))
                    {
                        $_SESSION["cart"][$i] = $item_array;
                        sort($_SESSION["cart"]);
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
               
            }
            else
            {
                $index = array_search($_POST['hidden_id'],array_column($_SESSION["cart"],"id"));
                $_SESSION["cart"][$index]['quantity'] += $item_array['quantity'];
            }
        }
        else
        {
            $item_array = array(
                'id' => $_POST["hidden_id"],
                'name' => $_POST["hidden_name"],
                'price' => $_POST["hidden_price"],
                'quantity' => $_POST["quantity"],
            );
            $_SESSION["cart"][0] = $item_array;
        }
    }
    if (isset($_POST["remove"]))
    {
        foreach ($_SESSION["cart"] as $keys => $value)
        {
            if ($value["id"] == $_POST["hidden_id"])
            {
                unset($_SESSION["cart"][$keys]);
            }
        }
    }
?>

<!DOCTYPE html>
<html>
<head>
    <style type="text/css">
    	.card-img-top
    	{ height: 300px; }
        th,td
        { padding-top: 2px;
            padding-bottom: 2px;
        }
        li .effect,.head
        {
          display: block;
          color: #000;
          padding: 8px 16px;
          text-decoration: none;
        }
        li .effect:hover:not(.active)
        {
          background-color: #555;
          border-radius: 25px;
          color: white;
          cursor: pointer;
        }
    </style>
</head>
<body>
      
    <div class="container-fluid">
        <!--  For Floating_Menu-->
      <ul style="list-style-type: none;margin-top: .5%;padding: 0;width: 15%;background-color:rgb(255, 255, 255);position: fixed;min-height: 50%;overflow: auto;" class="rounded">
        <li><a href="index.php" class="head" style="text-decoration: none; background-color: #4CAF50;color: white;">Home</a></li>
        <li><div id="accordion">
                <a class="effect" data-toggle="collapse" href="#category_collapse">Category</a>
                <div id="category_collapse" class="collapse text-right" data-parent="#accordion">
                    <a class="btn btn-lg" href="#">Category A</a><br>
                    <a class="btn btn-lg" href="#">Category B</a>
                </div>
                <a class="effect" data-toggle="collapse" href="#brand_collapse">Brand</a>
                <div id="brand_collapse" class="collapse text-right" data-parent="#accordion">
                    <a class="btn btn-lg" href="#">Brand A</a><br>
                    <a class="btn btn-lg" href="#">Brand B</a>
                </div>
                <a class="effect" data-toggle="collapse" href="#price_collapse">Price</a>
                <div id="price_collapse" class="collapse text-right" data-parent="#accordion">
                    <a class="btn btn-lg" href="#">Price A</a><br>
                    <a class="btn btn-lg" href="#">Price B</a>
                </div>
                <a class="effect" data-toggle="collapse" href="#goodies_collapse">Goodies</a>
                <div id="goodies_collapse" class="collapse text-right" data-parent="#accordion">
                    <a class="btn btn-lg" href="#">Goodies A</a><br>
                    <a class="btn btn-lg" href="#">Goodies B</a>
                </div>
            </div>
        </li>
        </ul>

        <!--  For Floating_Cart-->
        <ul style="list-style-type: none;margin-top: .5%;padding: 0;width: auto;background-color:rgb(255, 255, 255);position: fixed;overflow: auto;margin-left: 82%;" class="rounded">
          <li><a href="cart.php" class="head" style="background-color: #4CAF50;color: white;">Shopping Cart</a></li>
          <li>
            <table> 
                <?php 
                if(!empty($_SESSION["cart"]))
                {  
                    $total=0;
                    foreach ($_SESSION["cart"] as $key => $value) 
                    { 
                ?>
                
                 <form method="POST">
                        <tr class="text-center">
                            <td style="font-size:90%;text-align: left;"><?= $value["name"]; ?><input type="hidden" name="hidden_name" value="<?= $value['name']?>"><input type="hidden" name="hidden_price" value="<?= $value['price']?>"><input type="hidden" name="hidden_id" value="<?= $value['id']?>"></td>
                            <td><input type="number" name="quantity" style="width:50px;" class="rounded border-success text-center" min="10" value="<?= $value["quantity"]; ?>" required></td>
                            <td><input type="submit" name="update" value="Update" class="btn btn-sm btn-warning"></td>
                            <td><input type="submit" name="remove" value="Remove" class="btn btn-sm btn-danger"></td>
                        </tr>
                    </form>
                <?php
                $total = $total + $value["quantity"] * $value["price"];
        }   ?>
            <tr class="text-right">
                <td colspan="4"><h4 class="mr-3 mt-2"> Total Amount<br>Rs. <?php echo number_format($total, 2); }?></h4></td>
            </tr>
            </table>
        </li>
        <li><a href="checkout.php" class="btn btn-block">Checkout</a></li>
        </ul>

        <div style="margin:.5% 19% 2% 19%;">
            <span class="d-flex">
                <h1 class="text-danger">Products</h1>&nbsp;
                <input type="text" class="form-control-sm mt-1" name="view" value="ALL PRODUCTS" disabled>
            </span>
        <div class="row mt-2">
        <?php 
            $conn = mysqli_connect("localhost","root","","epharma");
            $query = "SELECT *,P.name AS name,P.id AS pid FROM product P LEFT JOIN  category C ON P.category=C.name  ";
            $result = mysqli_query($conn,$query);
            if(mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_array($result)) {
                    ?>
                        <form method="POST" action="cart.php" class="text-center col-md-3">
                            <table class="border rounded m-2 text-center">
                                <tr>
                                    <td>
                                        <a href="#" class="hovereffect d-flex flex-wrap align-content-end" style="height: 200px;;width: 100%;">
                                            <img src="<?php echo $row["image"]; ?>" class="img-fluid mb-2">
                                            <h2 class="overlay d-flex flex-wrap align-content-center">
                                                <?php  
                                                    echo $row["description"];
                                                ?>
                                            </h2>
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-info font-weight-bold"><?php echo $row["name"]; ?></td>
                                </tr>
                                <tr>
                                     <td class="text-danger">Price : Rs <?php echo $row["price"]; ?></td>
                                </tr>
                                <tr>
                                    <td><input type="hidden" name="hidden_id" value="<?= $row['pid']; ?>" ></td>
                                    <td><input type="hidden" name="hidden_name" value="<?= $row['name']; ?>"></td>
                                    <td><input type="hidden" name="hidden_price" value="<?= $row['price']; ?>"></td>
                                </tr>
                                <tr>
                                    <td>Quantity : &nbsp;<input type="number" name="quantity" style="width:30%;" class="rounded border-success text-center" min="10" placeholder="m.10" required></td>
                                </tr>
                                <tr>
                                    <td><input type="submit" name="add" class="btn btn-outline-success btn-block mt-2"
                                       value="Add to Cart"></td>
                                       
                                </tr>
                            </table>
                        </form>
                    <?php
                }
            }
        ?>
        </div>

        
        </div>
        <?php include 'include/footer.php' ?>
    </div>
</body>
</html>
