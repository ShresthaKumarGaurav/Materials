<?php include 'include/navbar.php' ?>
<!DOCTYPE html>
<html>
<head>
  <link rel="icon" href="images/good.png" type="image/png">
  <style type="text/css">
   /* Make the image fully responsive */
   .carousel-inner img {
     width: 1920px;
     height: 500px;
   }
   .card-img-top
   { height: 300px;
   }
 
</style>
</head>
<body>
 <div class="content" style="height: 500PX;">
   <div id="landingslider" class="carousel slide" data-ride="carousel">
    <ul class="carousel-indicators">
      <li data-target="#landingslider" data-slide-to="0" class="active"></li>
      <li data-target="#landingslider" data-slide-to="1"></li>
      <li data-target="#landingslider" data-slide-to="2"></li>
    </ul>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="images/carousel1.png" alt="slideImage"> 
      </div>
      <div class="carousel-item">
        <img src="images/carousel2.png" alt="slideImage">
      </div>
      <div class="carousel-item">
        <img src="images/carousel3.jpeg" alt="slideImage">
      </div>
    </div>
    <a class="carousel-control-prev" href="#landingslider" data-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" href="#landingslider" data-slide="next">
      <span class="carousel-control-next-icon"></span>
    </a>
  </div>
</div>

<br>
<div class="jumbotron" style="padding: 20px;width: 80%;margin-left: 10%;">
  <div class="d-flex justify-content-end">
    <a href="cart.php" class="btn btn-warning " >More ..</a>
</div><h2 class="mt--1 mb-5 text-center"><span class="text-success font-weight-bold">Top</span> Selling <span class="text-info">Products</span></h2>
        <div class="row d-flex justify-content-center">

        <?php
            $query = "SELECT *,P.name AS name,P.id AS pid FROM product P LEFT JOIN  category C ON P.category=C.name  ";
            $result = mysqli_query($conn,$query);

        for ($i=0; $i < 3; $i++) 
          { $row = mysqli_fetch_array($result);
        ?>
        
        <div class="col-md-3 text-center">
            <a href="#" class="hovereffect d-flex flex-wrap align-content-end" style="height: 250px;width: 100%;">
              <img src="<?php echo $row["image"]; ?>" class="img-fluid mb-2">
                <h2 class="overlay d-flex flex-wrap align-content-center" style="text-align: center;">
                    <?php  
                        echo $row["description"];
                    ?>
                </h2>
            </a>         
              <span class="text-info"><?php echo $row["name"]; ?></span>
              <input type="hidden" name="hidden_name" value="<?php echo $row["name"];?>"><br>
              <span class="text-danger">Price : Rs <?php echo $row["price"]; ?></span>
              <input type="hidden" name="hidden_price" value="<?php echo $row["price"];?>"><br>
              Quantity : &nbsp;<input type="number" name="quantity" min="10" placeholder="m.10" style="width:30%;" class="rounded border-success text-center" min="10" ;><br><br>
              <a href="#" class="btn btn-outline-success btn-block">Add to Cart</a>
        </div>
        <?php } ?>
                </div>

  </div>
</div>

  <?php include 'include/footer.php' ?>

</body>
</html>