<?php include 'DBConnect.php' ?>
<!DOCTYPE html>
<html>
<head>
  <link rel="icon" href="images/good.png" type="image/png">
	<style type="text/css">
   /* Make the image fully responsive */
   .carousel-inner img {
     width: 1920px;
     height: 500px;
   }
   .card-img-top
   { height: 300px;
   }
 }
</style>
</head>
<body>
  <?php include 'include/navbar.php' ?>
 <div class="content" style="height: 500PX;">
   <div id="landingslider" class="carousel slide" data-ride="carousel">
    <ul class="carousel-indicators">
      <li data-target="#landingslider" data-slide-to="0" class="active"></li>
      <li data-target="#landingslider" data-slide-to="1"></li>
      <li data-target="#landingslider" data-slide-to="2"></li>
    </ul>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="images/carousel1.png" alt="slideImage"> 
      </div>
      <div class="carousel-item">
        <img src="images/carousel2.png" alt="slideImage">
      </div>
      <div class="carousel-item">
        <img src="images/carousel3.jpeg" alt="slideImage">
      </div>
    </div>
    <a class="carousel-control-prev" href="#landingslider" data-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" href="#landingslider" data-slide="next">
      <span class="carousel-control-next-icon"></span>
    </a>
  </div>
</div>
<!--
<div class="ab" style="height: 150px;" >
	<section class="s1">
		<a href="#" class="iconbtn fas fa-truck" style="text-decoration: none;" ></a>
		<a href="#" class="iconbtn fas fa-money-bill-wave" style="text-decoration: none;"></a>
		<a href="#" class="iconbtn fas fa-shipping-fast" style="text-decoration: none;" ></a>

</section>
</div>
--><br>
<div class="jumbotron" style="padding: 20px;width: 80%;margin-left: 10%;">
  <div class="d-flex justify-content-end mb-3">
    <a href="cart.php" class="btn btn-warning " >More ..</a>
  </div>

  <div id="grid_slider" class="carousel slide ml-5" data-ride="carousel">
    <!-- The slideshow -->
    <div class="carousel-inner">

      <div class="carousel-item active">
        <div class="card-deck">
        <?php
            $query = "SELECT * FROM shopping ORDER BY id ASC ";
            $result = mysqli_query($conn,$query);
        for ($i=0; $i < 3; $i++) 
          { $row = mysqli_fetch_array($result);
        ?>
          <div class="card">
            <a href="#" class="hovereffect">
              <img  src="<?php echo $row["image"]; ?>"class="card-img-top img-fluid" style="height: 300px;width: 300px">
              <h2 class="overlay">Click on this image to view more about product</h2>
            </a>
            <div class="card-body">
              <h4 class="card-title text-center"><?php echo $row["name"]; ?></h4>
              <a href="#" class="btn btn-info btn-block">Add to Cart</a>
            </div>
          </div>
        <?php } ?>
        </div>
      </div>

      </div>
    </div>

    <!-- Left and right controls 
    <a class="carousel-control-prev bg-dark rounded" href="#grid_slider" data-slide="prev" style="width: 3.4%;margin-left: -4.3%;height: 50px; margin-top: 16%;">
      <span class="carousel-control-prev-icon text-primary"></span>
    </a>
    <a class="carousel-control-next bg-dark rounded" href="#grid_slider" data-slide="next" style="width: 3.4%;margin-right: -0.3%;height: 50px; margin-top: 16%;">
      <span class="carousel-control-next-icon text-primary"></span>
    </a>-->
  </div>
</div>

	<?php include 'include/footer.php' ?>

</body>
</html>