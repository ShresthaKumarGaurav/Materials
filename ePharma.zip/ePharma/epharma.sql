-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 01, 2020 at 03:08 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `epharma`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `about` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`id`, `name`, `about`) VALUES
(1, 'Nepal Jadibuti Corp', 'Jadibuti Prali'),
(2, 'Niko', 'Nepali Brand'),
(4, 'Patanjali Foundation', 'Ayurvedic medicines and ointments');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `item_name` text NOT NULL,
  `item_price` int(11) NOT NULL,
  `item_quantity` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `bill` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `item_name`, `item_price`, `item_quantity`, `total`, `bill`) VALUES
(1, 'Paracetamol', 150, 12, 1800, 0),
(3, 'Cotton', 30, 11, 330, 0),
(4, 'Mask', 20, 41, 820, 0),
(6, 'Cough Syrup', 100, 31, 3100, 0),
(7, 'ENO', 90, 10, 900, 0);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `description`) VALUES
(1, 'A', 'Used for common headaches and common fevers'),
(2, 'B', 'Beneficial for acidity cure'),
(5, 'C', 'Category C'),
(6, 'D', 'Category D'),
(7, 'E', 'Category E'),
(8, 'F', 'Category F'),
(9, 'Pain Killer', 'Relieves pain'),
(10, 'Analgesic', 'Analgesic medicines');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `area` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`area`) VALUES
('Asan'),
('Kalimati'),
('Dallu'),
('Lagankhel'),
('Dhapakhel'),
('Lainchaur'),
('Lazimpat'),
('Thamel'),
('Sorakhutte'),
('Swoyambhu'),
('Balaju'),
('Banasthali'),
('Gongabu'),
('Sitapaila'),
('Kalanki'),
('Balkhu'),
('Dhobighat'),
('Ekantakuna'),
('Bhaisepati'),
('Naikap'),
('Suryabinayak'),
('Sallaghari'),
('Mangalbazar'),
('Gwarko');

-- --------------------------------------------------------

--
-- Table structure for table `ordered_products`
--

CREATE TABLE `ordered_products` (
  `order_number` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `order_by_id` int(11) NOT NULL,
  `sold_by_id` int(11) NOT NULL,
  `amount` text NOT NULL,
  `payment_type` text NOT NULL,
  `remark` text NOT NULL,
  `placed_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` text NOT NULL DEFAULT 'on'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_by_id`, `sold_by_id`, `amount`, `payment_type`, `remark`, `placed_at`, `status`) VALUES
(1, 2, 1, '500', 'online', '', '2020-07-26 12:25:14', 'on'),
(2, 1, 2, '4100', 'online', '', '2020-07-26 14:49:34', 'cancelled'),
(3, 2, 1, '2500', '', '', '2020-07-26 12:25:17', 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `otp`
--

CREATE TABLE `otp` (
  `email` varchar(20) NOT NULL,
  `otpcode` int(11) NOT NULL,
  `timestamp` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `otp`
--

INSERT INTO `otp` (`email`, `otpcode`, `timestamp`) VALUES
('', 346494, 1591780494),
('ABC', 123456, 20200610111725);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `type` text NOT NULL,
  `vendor` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy`
--

CREATE TABLE `pharmacy` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `registration_number` text NOT NULL,
  `address` text NOT NULL,
  `contact` bigint(20) NOT NULL,
  `owner` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `verification` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pharmacy`
--

INSERT INTO `pharmacy` (`id`, `name`, `registration_number`, `address`, `contact`, `owner`, `status`, `verification`, `created_at`) VALUES
(1, 'Ram Pharmacy', '4545848845', 'Jorpati', 9800000000, 'Ram Maharjan', 1, 1, '2020-07-09 05:39:39'),
(2, 'Hamro Pharmacy', '4545645456456', '', 0, '', 0, 0, '2020-07-26 16:20:30');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` tinytext NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `category` text NOT NULL,
  `brand` text NOT NULL,
  `pharmacy_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `image`, `price`, `stock`, `category`, `brand`, `pharmacy_id`) VALUES
(1, 'Paracetamol', 'images/1.png', 150, 100, 'A', 'Niko', 45),
(3, 'Cotton', 'images/2.jpeg', 30, 300, 'B', 'Nepal Jadibuti Corp', 0),
(4, 'Mask', 'images/3.jpeg', 20, 500, 'A', 'Niko', 0),
(6, 'Cough Syrup', 'images/5.jpg', 100, 200, 'A', 'Niko', 1),
(7, 'ENO', 'images/6.jpg', 90, 400, 'B', '', 1),
(13, 'Patanjali Balm', '', 50, 20, 'C', 'Patanjali Foundation', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `discount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`order_id`, `product_id`, `quantity`, `discount`) VALUES
(1, 6, 10, 0),
(2, 7, 100, 100),
(3, 3, 550, 20);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `firstname` text NOT NULL,
  `middlename` text NOT NULL,
  `lastname` text NOT NULL,
  `dob` date NOT NULL,
  `gender` text NOT NULL,
  `password` text NOT NULL,
  `area` text NOT NULL,
  `district` text NOT NULL,
  `contact` bigint(11) NOT NULL,
  `email` text NOT NULL,
  `transaction_code` int(11) NOT NULL,
  `status` int(11) DEFAULT 1,
  `verification` int(11) DEFAULT 1,
  `usertype` text NOT NULL,
  `admin_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `firstname`, `middlename`, `lastname`, `dob`, `gender`, `password`, `area`, `district`, `contact`, `email`, `transaction_code`, `status`, `verification`, `usertype`, `admin_id`, `created_at`) VALUES
(1, 'shrestha', 'Gaurav', '', 'Shrestha', '1999-03-09', 'male', 'farm', 'Asan', 'Lalitpur', 9860484232, 'shrestha@gmail.com', 0, 1, 1, 'SuperAdmin', 0, '2020-07-07 13:41:36'),
(2, 'shahid', 'Shahid', '', 'Rehman', '1995-05-16', 'male', 'sample', 'Kalimati', 'kashmir', 9812345678, 'shahid@gmail.com', 0, 1, 1, 'Admin', 1, '2020-07-07 13:24:58'),
(27, 'qwerty', '', '', '', '0000-00-00', '', 'qqqqqqqq', '', '', 0, '', 0, 1, 1, 'Buyer', 0, '2020-07-26 16:24:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `otp`
--
ALTER TABLE `otp`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `pharmacy`
--
ALTER TABLE `pharmacy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pharmacy`
--
ALTER TABLE `pharmacy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
