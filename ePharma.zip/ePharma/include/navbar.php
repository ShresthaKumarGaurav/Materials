<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/style.css">
<div class="navbar">
	<a href="index.php" class="logo">ePharma</a>
	<ul class="nav">
		<li><a href="index.php">Home</a></li> 
		<li><a href="about.php">About Us</a></li>
		<li><a href="cart.php">Products</a></li>
		<li><a href="#">Health Tips</a></li>
		<li><a href="#">Contact Us</a></li>
		<li><a href="checkout.php">My Cart</a></li>
	</ul>
</div>