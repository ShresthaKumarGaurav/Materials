<?php 
include 'include/navbar.php';
	if (isset($_POST['reload']))
	{
		$_SESSION['tempuser'] = $_POST['email'];
		$_SESSION['pager']="resetpassword";
		header("Location: mailing.php");
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Email verification</title>
	<link rel="stylesheet" type="text/css" href="css/argon.css">
</head>
<body>
	<div class="d-flex justify-content-center">
		<div style="margin-top: 5%;width: 20%;">
			<form method="POST" name="resetpassword" class="text-center">
				Your Email address:<br><br>
				<input type="email" name="email" class="form-control"><br>
				<input type="submit" class="btn btn-primary btn-block" name="reload" value="Reset password now"><br>
			</form>
		</div>
	</div>
</body>
</html>
	