<?php
$t = 12345;
echo "<script>alert(".$t.")</script>";
?>