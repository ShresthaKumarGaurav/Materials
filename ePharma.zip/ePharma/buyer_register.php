<?php include 'include/navbar.php' ?>

<?php
if(isset($_COOKIE["member_login"]))
{	
	$_SESSION['username'] = $_COOKIE["member_login"];	
}
if(isset($_SESSION['username']))
{
	echo "<script>window.location='Cart.php';</script>";
	exit;
}
?>

<!DOCTYPE html>
<html><head>
	<title>Register with Us !!</title>
	<style type="text/css">
		input
		{ text-align: center; }
	</style>
</head>
<body>
	<form method="POST" class="container jumbotron form-group" action="addtodb.php" style="width: 70%;padding: 2rem;" onsubmit="return verify_password()" name="abc">
		<h1 style="font-family: sans-serif;" class="mt-5">Buyer Registration Form</h1>
		<p>Please fill in this form to create an account.</p>
		<hr>
		<!--For UserName-->
		<div class="input-group">
			<label for="username" class="input-group-prepend mr-sm-3">Your Name :<sup> *</sup></label>
			<input type="text"  class="form-control form-control-sm mb-1" minlength="3" placeholder="First Name*" name="first_name" required>
			<input type="text" class="form-control form-control-sm mb-1" minlength="3" placeholder="Middle Name" name="middle_name">
			<input type="text" class="form-control form-control-sm mb-1" minlength="3" placeholder="Last Name*" name="last_name" required>
		</div><br>
		<div class="input-group">
			<label for="address">Address : <sup> *</sup></label>
			<input type="text" name="address" id="address" class="form-control form-control-sm ml-5" style="max-width: 100%;" required>
		</div><br>
		<div class="input-group">
			<label for="dob">Date of birth : <sup> *</sup></label>&nbsp;&nbsp;
			<input type="date" name="dob" id="dob" class="form-control form-control-sm ml-3" style="max-width: 20%;" required>
		</div><br>
		<!--For Contact-->
		<label for="contact" class="mr-sm-3">Contact Information :<sup> *</sup></label>
		<input type="number" name="contact" class="form-control form-control-sm mb-3" min="9800000000" max="9888888888" required>
		<!--For Email-->
		<label for="email" class="mr-sm-3">Email address :</label>
		<div class="input-group input-group-sm mb-1"> 
			<input type="email" class="form-control" minlength="10" name="email">
			<div class="input-group-append"><span class="input-group-text mb-3">Example: admin@yahoo.com</span></div>
		</div>
		<!--For Gender-->
		<label for="gender" class="mb-3">Gender : &nbsp;</label>
		<div class="custom-control custom-radio custom-control-inline">
			<input type="radio" class="custom-control-input" name="gender" id="customRadio" value="male">
			<label class="custom-control-label" for="customRadio">Male</label>
		</div>
		<div class="custom-control custom-radio custom-control-inline">
			<input type="radio" class="custom-control-input" id="customRadio2" name="gender" value="female">
			<label class="custom-control-label" for="customRadio2">Female</label>
		</div>
		<div class="custom-control custom-radio custom-control-inline">
			<input type="radio" class="custom-control-input" id="customRadio3" name="gender" value="other">
			<label class="custom-control-label" for="customRadio3">Other</label>
		</div><br>
		<select name="area" class="custom-select mb-3">
			<option disabled selected>-- Neighbourhood --</option>
			<option>Asan</option>
		</select>
	    <label for="username" class="mr-sm-3">Username :<sup> *</sup></label>
		<input type="text" name="username" class="form-control form-control-sm mb-1 text-center" minlength="8" required placeholder="Remember this for future use">
		<label for="password" class="mr-sm-3">Enter password :<sup> *</sup></label>
		<input type="password" name="pass" class="form-control form-control-sm mb-1" minlength="8" required>
		<label for="re-password" class="mr-sm-3">Re-enter password :<sup> *</sup></label>
		<input type="password" name="repass" class="form-control form-control-sm mb-1" minlength="8" required>
		<br><input  type="submit" name="add_buyer" class="btn btn-outline-success" value="Register Now" style="float: right;">
		<p>Already have an account? <a href="login.php">Log In</a> .</p>
	</form>
	<?php include 'include/footer.php' ?>
</body>
<script>
	function verify_password() {
		var x = document.forms["abc"]["pass"].value;
		var y = document.forms["abc"]["repass"].value;
		if (x != y)
		{
			alert("Passwords don't match, please verify");
			return false;
		}
	}
	$(".custom-file-input").on("change", function() {
		var fileName = $(this).val().split("\\").pop();
		$(this).siblings(".custom-file-label").addClass("selected").html(fileName);
	});
</script>
</html>