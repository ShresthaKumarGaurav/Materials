<?php
if (!isset($_SESSION))
{
	session_start();
}
include 'DBConnect.php';

$_SESSION['tempuser']=$_POST['email'];

if (isset($_POST['add_buyer']))  //For buyer
{	$username = $_POST['username'];
	$first_name = $_POST['first_name'];
	$middle_name = $_POST['middle_name'];
	$last_name = $_POST['last_name'];
	$address = $_POST['address'];
	$dob = $_POST['dob'];
	$contact = $_POST['contact'];
	$email = $_POST['email'];
	$gender = $_POST['gender'];
	$area = $_POST['area'];
	$pass = $_POST['pass'];
	$repass = $_POST['repass'];
	$fullname = $first_name." ".$middle_name." ".$last_name;

		$sql = "INSERT INTO `user` (`username`,`firstname`,`middlename`,`lastname`,`address`,`dob`,`password`,`contact`,`email`,`gender`,`area`,`usertype`,`verification`) VALUES ('$username','$first_name','$middle_name','$last_name','$address','$dob','$pass','$contact','$email','$gender','$area','Buyer','0')";
		if (mysqli_query($conn, $sql))
			{ $_SESSION['pager']="verify";
				header("Location: mailing.php");
			}
		else
			{ echo "<script>alert('A technical problem occured, please retry later.\\nWe apologize for the inconvinience caused');</script>"; exit; 
			}

}
else if (isset($_POST['add_seller']))  //For seller
{	$username = $_POST['username'];
	$first_name = $_POST['first_name'];
	$middle_name = $_POST['middle_name'];
	$last_name = $_POST['last_name'];
	$address = $_POST['address'];
	$dob = $_POST['dob'];
	$shopname = $_POST['shopname'];
	$contact = $_POST['contact'];
	$email = $_POST['email'];
	$gender = $_POST['gender'];
	$area = $_POST['area'];
	$pass = $_POST['pass'];
	$repass = $_POST['repass'];
	$fullname = $first_name." ".$middle_name." ".$last_name;

	$sql = "INSERT INTO `pharmacy` (`name`,`address`,`contact`,`owner`,`verification`) VALUES ('$shopname','$address','$contact','$fullname','0')";
	if (mysqli_query($conn, $sql)) 
		{	$sql = "SELECT * FROM pharmacy WHERE `name`='$shopname'";
	$result = mysqli_query($conn, $sql);
	if ($result)
	{
		$row = mysqli_fetch_assoc($result);
		$admin_id = $row['id'];
		$sql = "INSERT INTO `user` (`username`,`firstname`,`middlename`,`lastname`,`address`,`dob`,`password`,`contact`,`email`,`gender`,`area`,`usertype`,`admin_id`,`otp`,`verification`) VALUES ('$username','$first_name','$middle_name','$last_name','$address','$dob','$password','$contact','$email','$gender','$area','Admin','$admin_id','0')";
		if (mysqli_query($conn, $sql))
			{ $_SESSION['pager']="verify";
				header("Location: mailing.php");
			}
		else
			{ echo "<script>alert('A technical problem occured, please retry later.\\nWe apologize for the inconvinience caused');</script>"; exit; }

	}
	else
		{ echo "<script>alert('A technical problem occured, please retry later.\\nWe apologize for the inconvinience caused');</script>"; exit;}

	}
	else
		{ echo "<script>alert('A technical problem occured, please retry later.\\nWe apologize for the inconvinience caused');</script>";exit;
	}


}

?>