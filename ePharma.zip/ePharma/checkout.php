<?php include 'include/navbar.php' ?>

<?php
    if (isset($_POST["updater"]))
    {
            $item_array = array(
                    'id' => $_POST["hidden_id"],
                    'name' => $_POST["hidden_name"],
                    'price' => $_POST["hidden_price"],
                    'quantity' => $_POST["quantity"],
                );
            $index = array_search($_POST['hidden_id'],array_column($_SESSION["cart"],"id"));
            $_SESSION["cart"][$index] = $item_array;
    }
    if (isset($_GET["action"]))
    {
        $temp = 0;
        $count = 0;
        foreach ($_SESSION["cart"] as $keys => $value)
        { 
            if ($value["id"] == $_GET["id"])
            {
                unset($_SESSION["cart"][$keys]);
                $temp = 1;
                $count = count($_SESSION["cart"]);
            }
            if ($temp==1 && $count!=$keys)  //for shifting following arrays forward
            {   $nxt = $keys ;
                $nxt++;
                $_SESSION["cart"][$keys]["id"] = $_SESSION["cart"][$nxt]["id"];
                $_SESSION["cart"][$keys]["name"] = $_SESSION["cart"][$nxt]["name"];
                $_SESSION["cart"][$keys]["price"] = $_SESSION["cart"][$nxt]["price"];
                $_SESSION["cart"][$keys]["quantity"] = $_SESSION["cart"][$nxt]["quantity"];
            }
        }
        sort($_SESSION["cart"]);
        array_pop($_SESSION["cart"]);
    }
?>

<?php 
    if (isset($_POST["checkout"]))
    {
        if (isset($_SESSION['username']))
        { echo "<script>window.location='order_now.php';</script>"; }
        else
        { echo "<script><alert('You must log in first');</script>"; }
    }
?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<h3 class="mt-4 mb-4 container">Shopping Cart Details</h3>
        
            <table class="table table-bordered container">
                <tr>
                    <th width="30%">Product Name</th>
                    <th width="10%">Quantity</th>
                    <th width="13%">Price Details</th>
                    <th width="10%">Total Price</th>
                    <th width="17%">Remove Item</th>
                </tr>

                <?php 
                if(!empty($_SESSION["cart"]))
                {  
                    $total=0;
                    foreach ($_SESSION["cart"] as $key => $value) 
                    { 
                ?>  <form method="POST">
                    <tr>
                        <td>
                            <?php echo $value["name"]; ?><input type="hidden" name="hidden_id" value="<?= $value["id"]; ?>" ><input type="hidden" name="hidden_name" value="<?= $value["name"]; ?>">
                        </td>
                        <td>
                            <input type="number" name="quantity" min="10" style="width:50%;" class="rounded border-success text-center mr-2" value="<?php echo $value["quantity"]; ?>"><input type="submit" name="updater" value="Update" class="btn btn-sm btn-warning mr-5">
                        </td>
                        <td>
                            Rs. <?php echo $value["price"]; ?><input type="hidden" name="hidden_price" value="<?= $value["price"]; ?>">
                        </td>
                        <td>
                            Rs. <?php echo number_format($value["quantity"] * $value["price"], 2); ?>
                        </td>
                        <td>
                            <a onclick="return confirm('Are you sure you want to delete this entry?')" href="checkout.php?action=delete&id=<?php echo $value["id"]; ?>"><span class="text-danger">Remove Item</span></a>
                        </td>
                    </tr>
                    </form>
                            <?php
                            $total = $total + $value["quantity"] * $value["price"];
                    }   
                    ?>
                            <tr class="font-weight-bold">
                                <td colspan="3" align="right">Total</td>
                                <td colspan="2">Rs. <?php echo number_format($total, 2); ?></td>
                                
                            </tr>
                            <?php 
                }   
                ?>
            </table>
        <form method="POST">
            <input type="submit" name="checkout" value="Checkout" class="btn btn-lg btn-outline-danger" style="margin-left: 25%;width: 50%;">
        </form>
<?php include 'include/footer.php' ?>
</body>
</html>