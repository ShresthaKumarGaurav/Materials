<?php
include 'include/navigation.php';
include "DBConnect.php";

// For extracting admin id from username
$a = $_SESSION['username'];             
$b = "SELECT * FROM `user` WHERE `username`='$a'";
$c = mysqli_query($conn,$b);
$d = mysqli_fetch_assoc($c);
$buyerid = $d['id'];
$admin_id = $d['admin_id'];
$usertype =  $d['usertype'];

//For extracting pharmacy name from id
$sql = "SELECT id FROM pharmacy WHERE id=$admin_id";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
$sellerid = $row["id"];


// Limiting Access to Owned Products Only
if ($usertype=="SuperAdmin")
{    $sql = "SELECT * FROM `orders`  ";
}
elseif ($usertype=="Admin")
{
    $sql = "SELECT * FROM orders WHERE sold_by_id=$sellerid";
}
elseif ($usertype=="Buyer")
{
    $sql = "SELECT * FROM orders WHERE order_by_id=$buyerid";
}

$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

<div class="container" style="width: 60%;margin-left:20%;margin-right: 20%;">
    <h1>View Orders</h1>
    <table class="text-center table-bordered table-primary table-hover table-sm mb-2 ">
        <tr>
            <th>Order ID</th>
            <?php if($usertype!="Buyer") {?>
                <th>Order By</th>
            <?php } ?>
            <?php if($usertype!="Admin") {?>
                <th>Sold By</th>
            <?php } ?>
            <th>Total Amount</th>
            <th>Placed Date</th>
            <th>Remarks</th>
            <th>Action</th>
        </tr>
        <?php
        if ($result) {
            while($row = mysqli_fetch_assoc($result)) {
        ?>
                <tr>
                    <td><?= $row["id"];?></td>
                <?php if($usertype!="Buyer") {?>
                    <td>
                        <?php
                            $keyy = $row["order_by_id"];;
                            $extract = mysqli_query($conn,"SELECT firstname,middlename,lastname FROM user WHERE id=$keyy");
                            $value = mysqli_fetch_assoc($extract);
                            echo $value['firstname']." ".$value['middlename']." ".$value['lastname'];

                        ?>
                    </td>
                <?php } if($usertype!="Admin") { ?>
                    <td>
                        <?php
                            $keyy = $row["sold_by_id"];;
                            $extract = mysqli_query($conn,"SELECT name FROM pharmacy WHERE id=$keyy");
                            $value = mysqli_fetch_assoc($extract);
                            echo $value['name'];
                        ?>
                    </td>
                <?php } ?>
                    <td>Rs.<?= $row["amount"];?></td>
                    <td><?= $row["placed_at"];?></td>
                    <td><?= $row["remark"];?></td>
                    <td>
                        <?php if($row['status']=="on") {?>
                            <a onclick="return confirm('Are you sure you want to delete this entry?')" href="order_cancel.php?id=<?= $row['id'];?>" class="text-danger" style="text-decoration: underline ;">Cancel Order</a>
                        <?php } elseif($row['status']=="cancelled") {?>
                            <font class="text-danger font-weight-bold">Cancelled</font>
                        <?php } else {?>
                            <font class="text-success font-weight-bold">Completed</font>
                        <?php } ?>
                    </td>
                </tr>
                <?php
            }   
        } else {
            ?>
            <tr>
                <td colspan="6">No Record(s) found.</td>
            </tr>
            <?php
        }
        ?>
    </table>
    <?php include 'include/footer.php';?>
</div>
</body>
</html>