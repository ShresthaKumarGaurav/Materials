<?php
if (isset($_POST['add_admin'])) {
	// echo "Nepal";exit();
	$u = $_POST['fullname'];
	$e = $_POST['email'];
	$ad = $_POST['address'];
	$c = $_POST['contact'];
	$p = $_POST['password'];
	$re_p = $_POST['password-re'];
	// echo 'U: '.$u.', E: '.$e.', P: '.$p;exit;
	if ($p != $re_p) 
	{
		echo '<script type="text/javascript">alert("Password & Confirm Password don\'t match.");</script>';
	}
	else{
			$sql = "INSERT INTO `admin` (`fullname`, `email`,`address`,`contact`,`password`) VALUES ('$u','$e','$ad','$c','$p')";
		require_once("DBConnect.php");
		if (mysqli_query($conn, $sql)) {
		    // echo "New record created successfully.";
		    header('Location: admin_list.php');
		} else {
		    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
		}
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php include 'include/navigation.php';?>
	<div class="container">
		<h1>Add Admin</h1>
		<form action="" method="POST" name="admin">
			<table class="table-sm mb-2">
				<tr>
					<td>Full Name : </td>
					<td><input type="text" name="fullname" class="form-control form-control-sm" required></td>
				</tr>
				<tr>
					<td>Email : </td>
					<td><input type="email" name="email" class="form-control form-control-sm" required></td>
				</tr>
				<tr>
					<td>Address : </td>
					<td><input type="text" name="address" class="form-control form-control-sm" required></td>
				</tr>
				<tr>
					<td>Contact : </td>
					<td><input type="number" name="contact" class="form-control form-control-sm" min="9800000000" max="9888888888" required></td>
				</tr>
				<tr>
					<td>Password : </td>
					<td><input type="password" name="password" class="form-control form-control-sm" required></td>
				</tr>
				<tr>
					<td>Confirm Password : </td>
					<td><input type="password" name="password-re" class="form-control form-control-sm" required></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td class="text-center"><button type="submit" name="add_admin" class="btn btn-success btn-block">Add</button></td>
				</tr>
			</table>
		</form>
		<?php include 'include/footer.php';?>
	</div>
</body>
</html>