<?php
include 'include/navigation.php';
include "DBConnect.php";

// For extracting admin id from username
$a = $_SESSION['username'];             
$b = "SELECT * FROM `user` WHERE `username`='$a'";
$c = mysqli_query($conn,$b);
$d = mysqli_fetch_assoc($c);
$buyerid = $d['id'];
$admin_id = $d['admin_id'];
$usertype =  $d['usertype'];

//For extracting pharmacy name from id
$sql = "SELECT id FROM pharmacy WHERE id=$admin_id";
$result= mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
$sellerid = $row["id"];


// Limiting Access to Owned Products Only
if ($usertype=="SuperAdmin")
{    $sql = $sql = "SELECT O.id,O.amount,S.quantity,S.discount,P.name,P.price,U.username AS OrderBy,Ph.name AS SoldBy FROM orders O JOIN sales S ON O.id=S.order_id JOIN product P ON S.product_id=P.id JOIN pharmacy Ph on O.sold_by_id=Ph.id JOIN user U on O.order_by_id=U.id GROUP BY O.id ASC";;
}
elseif ($usertype=="Admin")
{
    $sql = "SELECT O.id,O.amount,S.quantity,S.discount,P.name,P.price,U.username AS OrderBy,Ph.name AS SoldBy FROM orders O JOIN sales S ON O.id=S.order_id JOIN product P ON S.product_id=P.id JOIN pharmacy Ph on O.sold_by_id=Ph.id JOIN user U on O.order_by_id=U.id WHERE sold_by_id=$sellerid GROUP BY O.id ASC";
}
elseif ($usertype=="Buyer")
{
    $sql = "SELECT O.id,O.amount,S.quantity,S.discount,P.name,P.price,u1.firstname AS OrderBy,u2.firstname AS SoldBy FROM orders O JOIN sales S ON O.id=S.order_id JOIN product P ON S.product_id=P.id JOIN user u1 on O.order_by_id=u1.id JOIN user u2 on O.sold_by_id=u2.id ASC WHERE order_by_id=$buyerid GROUP BY O.id";
}

$result = mysqli_query($conn, $sql);
?>


<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<div class="container" style="width: 60%;margin-left:20%;margin-right: 20%;">
    <h1>View Sales</h1>
    <img src="images/bootstrap.jpg" height="30px">
    <table class="text-center table-bordered table-primary table-hover table-sm mb-2 ">
        <tr>
            <th>Transaction ID</th>
            <th>Product</th>
            <th>Quantity</th>
            <th>Price ( / )</th>
            <th>Discount</th>
            <?php if($usertype!="Buyer") {?>
                <th>Order By</th>
            <?php } if($usertype!="Admin") {?>
                <th>Sold By</th>
            <?php } ?>
            <th>Action</th>
        </tr>
        <?php
        if ($result) {
            while($row = mysqli_fetch_assoc($result)) {
        ?>
                <tr>
                    <td><?= $row["id"]?></td>
                    <td><?= $row["name"]?></td>
                    <td><?= $row["quantity"];?></td>
                    <td><?= $row["price"];?></td>
                    <td><?= $row["discount"];?></td>
                <?php if($usertype!="Buyer") {?>
                    <td><?= $row["OrderBy"];?></td>
                <?php } if($usertype!="Admin") {?>
                    <td><?= $row["SoldBy"];?></td>
                <?php } ?>
                    <td><a onclick="return confirm('Are you sure you want to delete this entry?')" href="sales_delete.php?id=<?= $row['id'];?>">Erase</a></td>
                </tr>
                <?php
            }   
        } else {
            ?>
            <tr>
                <td colspan="7">No Record(s) found.</td>
            </tr>
            <?php
        }
        ?>
        <?php 
        mysqli_close($conn);
        ?>
    </table>
    <?php include 'include/footer.php';?>
</div>
</body>
</html>