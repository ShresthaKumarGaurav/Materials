<?php
$shopname = @$_GET['shopname'];
if (!isset($shopname)) {
	header('Location: client_list.php');
}
include 'DBConnect.php';
$sql = "SELECT * FROM `client` WHERE `shopname`='$shopname'";
$result = mysqli_query($conn, $sql);
$prev_data = mysqli_fetch_assoc($result);
if (isset($_POST['updater'])) {
	$u = $_POST['fullname'];
	$dob = $_POST['dob'];
	$sn = $_POST['shopname'];
	$ad = $_POST['address'];
	$e = $_POST['email'];
	$c = $_POST['contact'];
	$p = $_POST['password'];
	$re_p = $_POST['password-re'];
	if ($p != $re_p) 
	{
		echo '<script type="text/javascript">alert("Password & Confirm Password don\'t match.");</script>';
	}
	else{
			$sql = "UPDATE`client` SET `fullname`='$u',`dob`='$dob',`shopname`='$sn',`address`='$ad',`email`='$e',`contact`='$c',`password`='$p'";
		if (mysqli_query($conn, $sql)) {
		    // echo "New record created successfully.";
		    header('Location: client_list.php');
		} else {
		    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
		}
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php include 'include/navigation.php';?>
<div class="container">
<h1>Update Client - <?= $prev_data['fullname'];?></h1>
<form action="" method="POST" name="client">
<table class="table-sm mb-2">
				<tr>
					<td>Full Name : </td>
					<td><input type="text" name="fullname" class="form-control form-control-sm" required value="<?= $prev_data['fullname'];?>"></td>
				</tr>
				<tr>
					<td>Date of Birth : </td>
					<td><input type="date" name="dob" class="form-control form-control-sm" required value="<?= $prev_data['dob'];?>"></td>
				</tr>
				<tr>
					<td>Shop Name : </td>
					<td><input type="text" name="shopname" class="form-control form-control-sm" required value="<?= $prev_data['shopname'];?>"></td>
				</tr>
				<tr>
					<td>Address : </td>
					<td><input type="text" name="address" class="form-control form-control-sm" required value="<?= $prev_data['address'];?>"></td>
				</tr>
				<tr>
					<td>Email : </td>
					<td><input type="email" name="email" class="form-control form-control-sm" required value="<?= $prev_data['email'];?>"></td>
				</tr>
				<tr>
					<td>Contact : </td>
					<td><input type="number" name="contact" class="form-control form-control-sm" min="9800000000" max="9888888888" required value="<?= $prev_data['contact'];?>"></td>
				</tr>
				<tr>
					<td>Password : </td>
					<td><input type="password" name="password" class="form-control form-control-sm" required value="<?= $prev_data['password'];?>"></td>
				</tr>
				<tr>
					<td>Confirm Password : </td>
					<td><input type="password" name="password-re" class="form-control form-control-sm" required value="<?= $prev_data['password'];?>"></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td class="text-center"><button type="submit" name="updater" class="btn btn-success btn-block">Update</button></td>
				</tr>
			</table>
</form>
	<?php include 'include/footer.php';?>
	</div>
</body>
</html>