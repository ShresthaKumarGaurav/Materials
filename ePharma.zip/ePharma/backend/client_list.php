<?php
require_once("DBConnect.php");
$sql = "SELECT * FROM `client`";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<?php include 'include/navigation.php';?>
<div class="container">
    <h1>Client List</h1>
    <a href="client_add.php"><img src="images/bootstrap.jpg" height="30px">+</a>
    <table class="text-center table-bordered table-primary table-hover table-sm mb-2">
        <tr>
            <th>S.N.</th>
            <th>Photo</th>
            <th>Full Name</th>
            <th>Date of Birth</th>
            <th>Shop Name</th>
            <th>Address</th>
            <th>Email</th>
            <th>Contact</th>
            <th>Verfied</th>
            <th>Action</th>
        </tr>
        <?php
        if (mysqli_num_rows($result) > 0) {
            $i=0;
            while($row = mysqli_fetch_assoc($result)) {
        ?>
                <tr>
                    <td><?= ++$i;?></td>
                    <td><?= $row["photo"];?></td>
                    <td><?= $row["fullname"];?></td>
                    <td><?= $row["dob"];?></td>
                    <td><?= $row["shopname"];?></td>
                    <td><?= $row["address"]; ?></td>
                    <td><?= $row["email"];?></td>
                    <td><?= $row["contact"]; ?></td>
                    <td><?= $row["verification"]?>  
                    </td>
                    <td><a href="client_update.php?shopname=<?= $row['shopname'];?>">Edit</a>&nbsp; | <a onclick="return confirm('Are you sure you want to delete this entry?')" href="client_delete.php?shopname=<?= $row['shopname'];?>">Delete</a></td>
                </tr>
                <?php
            }   
        } else {
            ?>
            <tr>
                <td colspan="4" class="border-0">No Record(s) found.</td>
            </tr>
            <?php
        }
        ?>
        <?php 
        mysqli_close($conn);
        ?>
    </table>
    <?php include 'include/footer.php';?>
</div>
</body>
</html>