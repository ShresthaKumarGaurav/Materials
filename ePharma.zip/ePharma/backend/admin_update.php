<?php
$user_id = @$_GET['id'];
if (!isset($user_id)) {
	header('Location: admin_list.php');
}
require_once("DBConnect.php");
$sql = "SELECT * FROM `admin` WHERE `id`='$user_id'";
$result = mysqli_query($conn, $sql);
$prev_data = mysqli_fetch_assoc($result);
if (isset($_POST['updater'])) {
	$user_id = $_GET['id'];
	// echo "$user_id";exit();
	$u = $_POST['fullname'];
	$e = $_POST['email'];
	$ad = $_POST['address'];
	$c = $_POST['contact'];
	$p = $_POST['password'];
	$re_p = $_POST['password-re'];
	// // echo 'U: '.$u.', E: '.$e.', P: '.$p;exit;
	// if ($p != $re_p) {
	// 	echo '<script type="text/javascript">alert("Password & Confirm Password don\'t match.");</script>';
	// }
if ($p != $re_p) 
	{
		echo '<script type="text/javascript">alert("Password & Confirm Password don\'t match.");</script>';
	}
	else{
			$sql = "UPDATE `admin` SET `fullname`='$u', `email`='$e', `address`='$ad', `contact`='$c', `password`='$p' WHERE `id`='$user_id';";
			// echo $sql;exit;

		require_once("DBConnect.php");
		if (mysqli_query($conn, $sql)) {
		    // echo "Record updated successfully";
		    header('Location: admin_list.php');
		} else {
		    echo "Error updating record: " . mysqli_error($conn);
		}
		mysqli_close($conn);
		}
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php include 'include/navigation.php';?>
<div class="container">
<h1>Update Admin #<?= $prev_data['id'];?></h1>
<form action="" method="POST" name="admin">
<table class="table-sm">
	<tr>
		<td>Full Name : </td>
		<td><input type="text" name="fullname" class="form-control form-control-sm" required value="<?= $prev_data['fullname'];?>"></td>
	</tr>
	<tr>
		<td>Email : </td>
		<td><input type="email" name="email" class="form-control form-control-sm" required value="<?= $prev_data['email'];?>"></td>
	</tr>
	<tr>
		<td>Address : </td>
		<td><input type="text" name="address" class="form-control form-control-sm" required value="<?= $prev_data['address'];?>"></td>
	</tr>
	<tr>
		<td>Contact : </td>
		<td><input type="number" name="contact" class="form-control form-control-sm" min="9800000000" max="9888888888" required value="<?= $prev_data['contact'];?>"></td>
	</tr>
	<tr>
		<td>Password:</td>
		<td><input type="password" name="password" class="form-control form-control-sm" required value="<?= $prev_data['password'];?>"></td>
	</tr>
	<tr>
		<td>Confirm Password:</td>
		<td><input type="password" name="password-re" class="form-control form-control-sm" required value="<?= $prev_data['password'];?>"></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><button type="submit" name="updater" class="btn btn-success btn-block mb-3">Update</button></td>
	</tr>
</table>
</form>
	<?php include 'include/footer.php';?>
	</div>
</body>
</html>