<?php
require_once("DBConnect.php");
$sql = "SELECT * FROM `drug`";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<?php include 'include/navigation.php';?>
<div class="container">
    <h1>Drug List</h1>
    <a href="drug_add.php"><img src="images/bootstrap.jpg" height="30px">+</a>
    <table class="text-center table-bordered table-primary table-hover table-sm mb-2">
        <tr>
            <th>S.N.</th>
            <th>Product Code</th>
            <th>Product Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Action</th>
        </tr>
        <?php
        if (mysqli_num_rows($result) > 0) {
            $i=0;
            while($row = mysqli_fetch_assoc($result)) {
        ?>
                <tr>
                    <td><?= ++$i;?></td>
                    <td>EP<?= $row["code"];?></td>
                    <td><?= $row["name"];?></td>
                    <td><?= $row["description"]; ?></td>
                    <td><?= $row["price"]; ?></td>
                    <td><a href="drug_update.php?code=<?= $row['code'];?>">Edit</a>&nbsp; | <a onclick="return confirm('Are you sure you want to delete this entry?')" href="drug_delete.php?code=<?= $row['code'];?>">Delete</a></td>
                </tr>
                <?php
            }   
        } else {
            ?>
            <tr>
                <td colspan="6">No Record(s) found.</td>
            </tr>
            <?php
        }
        ?>
        <?php 
        mysqli_close($conn);
        ?>
    </table>
    <?php include 'include/footer.php';?>
</div>
</body>
</html>