<?php
$shopname = @$_GET['shopname'];
if (!isset($user_id)) {
	header('Location: client_list.php');
}
 
require_once('DBConnect.php');
$sql = "DELETE FROM `client` WHERE shopname='$shopname';";

if (mysqli_query($conn, $sql)) {
    // echo "Record deleted successfully";
    header('Location: client_list.php');
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}